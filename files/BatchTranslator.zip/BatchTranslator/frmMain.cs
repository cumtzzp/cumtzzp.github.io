﻿using System;
using System.IO;
using System.Net;
using System.Web;
using System.Text;
using System.Data;
using System.Drawing;
using System.Diagnostics;
using System.Windows.Forms;
using System.ComponentModel;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Text.RegularExpressions;

using Aspose.Words;
using Newtonsoft.Json;


namespace BatchTranslator
{
    public partial class frmMain : Form
    {


        public frmMain()
        {
            InitializeComponent();
        }



        #region Private Consts & Variables


        /// <summary>
        /// Google Cloud Traslation API 密钥
        /// </summary>
        private const string GOOGLE_API_KEY = "AIzaS...........................";
        

        /// <summary>
        /// 百度翻译开放平台 APP ID
        /// </summary>
        private const string BAIDU_APP_ID = "2016..........";


        /// <summary>
        /// 百度翻译开放平台密钥
        /// </summary>
        private const string BAIDU_API_KEY = "8P...........";


        /// <summary>
        /// 翻译引擎，google / baidu，默认为 Google
        /// </summary>
        private string engine = "google";


        /// <summary>
        /// 使用 Google 云翻译 API 翻译文本
        /// </summary>
        /// <param name="from">原始文本语言</param>
        /// <param name="to">翻译文本语言</param>
        /// <param name="q">待翻译文本</param>
        /// <returns>翻译后文本</returns>
        private string googleTrans_Get(string from, string to, string q)
        {
            // 请求 URL
            string url = string.Format(
                "https://translation.googleapis.com/language/translate/v2?key={0}&source={1}&target={2}&q={3}",
                GOOGLE_API_KEY,
                from,
                to,
                HttpUtility.UrlEncode(q)
            );

            // GET 请求
            HttpWebRequest hwr = (HttpWebRequest)HttpWebRequest.Create(url);
            hwr.Method = "GET";
            
            string json = string.Empty;

            try
            {
                // 发送请求并获得相应
                using (StreamReader s = new StreamReader(hwr.GetResponse().GetResponseStream(), Encoding.UTF8))
                {
                    json = s.ReadToEnd();
                }
            }
            catch
            { 
            
            }

            // 解析返回后的 JSON 并返回翻译后文本
            return this.getPropertyValueFromJson("translatedText", json);

        }


        #endregion



        #region Functions


        /// <summary>
        /// 使用百度翻译开放平台 API 翻译文本
        /// </summary>
        /// <param name="from">原始文本语言</param>
        /// <param name="to">翻译文本语言</param>
        /// <param name="q">待翻译文本</param>
        /// <returns>翻译后文本</returns>
        private string baiduTrans_Post(string from, string to, string q)
        {

            // 生成随机数
            Random r = new Random(int.MaxValue);
            string salt = r.Next(1000000, int.MaxValue).ToString();


            // MD5 生成签名
            string sign = string.Empty;

            MD5 md5 = MD5.Create();
            byte[] s = md5.ComputeHash(Encoding.UTF8.GetBytes(BAIDU_APP_ID + q + salt + BAIDU_API_KEY));
            for (int i = 0; i < s.Length; i++)
            {
                // 将得到的字符串使用32进制类型格式。格式后的字符是小写的字母，如果使用大写（X）则格式后的字符是大写字符  
                sign += s[i].ToString("x");
            }

            // 请求 URL
            string url = string.Format(
                "http://api.fanyi.baidu.com/api/trans/vip/translate?appid={0}&salt={1}&from={2}&to={3}&sign={4}", 
                BAIDU_APP_ID, 
                salt, 
                from, 
                to, 
                sign
            );

            // 以POST方式发送数据
            string postData = string.Format("q={0}", HttpUtility.UrlEncode(q, Encoding.UTF8));
            byte[] bytes = Encoding.UTF8.GetBytes(postData);

            WebClient client = new WebClient();
            client.Encoding = Encoding.UTF8;
            client.Headers.Add("Content-Type", "application/x-www-form-urlencoded");
            client.Headers.Add("ContentLength", postData.Length.ToString());
            // 发送请求上传数据
            byte[] responseData = client.UploadData(url, "POST", bytes);

            // 取得响应结果 
            string translated = Encoding.GetEncoding("utf-8").GetString(responseData);

            // 取得相应结果中 dst 的实际值即翻译后文本
            translated = this.getPropertyValueFromJson("dst", translated);

            return translated;
        }


        /// <summary>
        /// 递归使用 Aspose.Words 遍历 Word 文档中的所有段落，逐段翻译后将翻译后文本插入到段落末尾处
        /// </summary>
        /// <param name="parentNode">从哪个父节点开始</param>
        /// <param name="db">用于修改文档插入译文的 DocumentBuilder 对象</param>
        public void traverseDocs(CompositeNode parentNode, DocumentBuilder db)
        {
            // 从指定父节点第一个节点开始，循环取下一兄弟节点，直到遍历完父节点的所有子节点
            for (Node childNode = parentNode.FirstChild; childNode != null; childNode = childNode.NextSibling)
            {
                // 只处理段落节点
                if (childNode.NodeType == NodeType.Paragraph)
                {
                    // 节点中的文本
                    string nodeText = childNode.Range.Text.Trim();

                    if (
                            nodeText != string.Empty &&                 // 节点文本为空不翻译
                            nodeText.Length > 5 &&                      // 节点文本长度小于 5 不翻译
                            !nodeText.ToUpper().StartsWith("ES-") &&    // 以 ES- 开始的文本不翻译，特殊文档需求
                            !nodeText.StartsWith("") &&                // 以  开始的节点文本不翻译，特殊文档需求
                            !nodeText.StartsWith("译：") &&             // 以“译：”开始的节点文本不翻译，这是新插入的翻译后文本
                            nodeText != "\r"                            // 文本为 \r 的不翻译
                        )
                    {
                        // 准备插入翻译后文本之前要将光标移动到当前节点（文本结束）处
                        db.MoveTo(childNode);

                        // 设置新插入译文的字型、高亮颜色和下划线
                        Aspose.Words.Font font = db.Font;
                        font.HighlightColor = Color.Aqua;
                        font.Underline = Underline.Dash;

                        // 翻译引擎在遇到一些特殊字符时将发生错误
                        // 使用正则表达式只取部分字符，此处仅取待翻译特定英文文档中可能的字符
                        nodeText = Regex.Replace(nodeText, @"[^A-Za-z0-9|||	|.|,|!|\-|)|(| |=|/|—|%|:|’|'|;|\[|\]]", string.Empty);
                        
                        // 将可能出现的一些超级链接、页码等信息替换掉不翻译
                        nodeText = Regex.Replace(nodeText, "HYPERLINK l Toc[0-9]{9}", string.Empty);
                        nodeText = Regex.Replace(nodeText, @"PAGEREF Toc[0-9]{9}\s{0,1}r{0,1}\s{0,1}h{0,1}", string.Empty);
                        nodeText = Regex.Replace(nodeText, @"REF Ref[0-9]{9}\s{0,1}r{0,1}\s{0,1}h{0,1}", string.Empty);
                        nodeText = Regex.Replace(nodeText, @"STYLEREF\s{0,1}1{0,1}\s{0,1}s{0,1}", string.Empty);
                        nodeText = Regex.Replace(nodeText, @"ARABIC\s{0,1}s{0,1}\s{0,1}1{0,1}", string.Empty);
                        nodeText = Regex.Replace(nodeText, @"MERGEFORMAT", string.Empty);

                        // 两个 Unicode 字符的处理：Device Control Four / Vertical Tabulation，均替换为一个空格
                        nodeText = Regex.Replace(nodeText, "|", " ");

                        // 根据用户选择获取不同引擎返回的译文
                        string translated =
                            this.engine == "google" ?
                            this.googleTrans_Get(this.txtLanguageOriginal.Text, this.txtLanguageDestination.Text, nodeText) :
                            this.baiduTrans_Post(this.txtLanguageOriginal.Text, this.txtLanguageDestination.Text, nodeText);

                        if (translated != string.Empty)
                        {
                            // 译文不为空字符串时在段落末尾处插入译文
                            db.Write("译：" + translated);
                        }
                    }

                    // 调试过程中非常有用
                    // 通过输出的信息监测应该去掉或者保留哪些特殊字符
                    // 用在上面的正则表达式中
                    Debug.WriteLine("----: " + childNode.GetText());

                }

                // 如果当前节点包含子节点，递归处理当前节点
                if (childNode.IsComposite)
                    traverseDocs((CompositeNode)childNode, db);
            }
        }


        /// <summary>
        /// 使用 Newtonsoft.Json 组件获取 JSON 字符串中指定属性的属性值
        /// </summary>
        /// <param name="property">指定属性名</param>
        /// <param name="json">JSON 字符串</param>
        /// <returns>指定属性名对应的属性值</returns>
        private string getPropertyValueFromJson(string property, string json)
        {
            string value = string.Empty;
            JsonTextReader reader = new JsonTextReader(new StringReader(json));
            int i = 0;
            int propertyIndex = -1000;
            while (reader.Read())
            {
                if (
                    reader.Value != null &&
                    reader.Value.ToString() == property &&
                    reader.TokenType == JsonToken.PropertyName
                )
                {
                    propertyIndex = i;
                }
                if (i == propertyIndex + 1)
                {
                    value = reader.Value.ToString();
                    break;
                }
                i++;
            }
            return value;
        }


        /// <summary>
        /// 控件验证
        /// </summary>
        /// <returns></returns>
        private bool validateControls()
        {
            bool validated = true;

            if (this.txtLanguageOriginal.Text.Trim() == string.Empty)
            {
                MessageBox.Show("原始语言不能为空！", "控件验证", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.txtLanguageOriginal.Focus();
                validated = false;
            }
            else if (this.txtLanguageDestination.Text.Trim() == string.Empty)
            {
                MessageBox.Show("目标语言不能为空！", "控件验证", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.txtLanguageDestination.Focus();
                validated = false;
            }
            else if (this.txtLanguageDestination.Text.Trim() == this.txtLanguageOriginal.Text.Trim())
            {
                MessageBox.Show("原始语言不能与目标语言相同", "控件验证", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.txtLanguageOriginal.Focus();
                validated = false;
            }

            return validated;
        }


        #endregion



        #region Events of Controls



        /// <summary>
        /// 窗体加载，设置翻译后的新文档保存路径
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void frmMain_Load(object sender, EventArgs e)
        {
            this.txtNewDocPath.Text = Application.StartupPath;
        }


        /// <summary>
        /// Google 翻译 API 支持的语言列表链接
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void lllGoogle_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Process.Start("https://cloud.google.com/translate/docs/languages");
        }


        /// <summary>
        /// Baidu 翻译 API 支持的语言列表链接
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void lllBaidu_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Process.Start("http://api.fanyi.baidu.com/api/trans/product/apidoc#languageList");
        }


        /// <summary>
        /// 切换来源和目标语言按钮
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSwapLanguage_Click(object sender, EventArgs e)
        {
            string s = this.txtLanguageDestination.Text.Trim();
            this.txtLanguageDestination.Text = this.txtLanguageOriginal.Text.Trim();
            this.txtLanguageOriginal.Text = s;
        }


        /// <summary>
        /// 文档翻译按钮
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnTransDoc_Click(object sender, EventArgs e)
        {
            if (!this.validateControls())
            {
                return;
            }

            if (this.txtDocFilePath.Text.Trim() == string.Empty)
            {
                MessageBox.Show("必须选择一个 Word 文档进行标注翻译！", "文档翻译", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.btnBrowse.Focus();
                return;
            }

            // 记录文档翻译开始时间
            DateTime begin = DateTime.Now;

            // Aspose.Words 文档对象，打开待翻译 Word 文档
            Document doc = new Document(this.txtDocFilePath.Text);

            // Aspose.Words 文档创建器对象，用于将各段落翻译内容插入到原始内容之后
            DocumentBuilder db = new DocumentBuilder(doc);

            // 遍历文档中所有段落，并完成翻译和插入译文工作
            traverseDocs(doc, db);

            // 获取原始文档扩展名，.doc / .docx
            string fileExt = this.txtDocFilePath.Text.Trim();
            fileExt = fileExt.Substring(fileExt.LastIndexOf(".") + 1);

            // 生成带时间戳的翻译后文档文件名
            string fileName = "translated_" + DateTime.Now.ToString("yyyyMMddHHmmssfffff") + "." + fileExt;

            // 保存翻译后的 Word 文档
            doc.Save(Path.Combine(this.txtNewDocPath.Text.Trim(), fileName));

            // 文档翻译结束的时间
            DateTime end = DateTime.Now;

            MessageBox.Show("处理完成！\r\n\r\n耗时： " + (end - begin).TotalSeconds.ToString() + " 秒。", "文档翻译", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }


        /// <summary>
        /// 文本翻译按钮
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnTranText_Click(object sender, EventArgs e)
        {
            this.txtDestination.Text = string.Empty;

            if (!this.validateControls())
            {
                return;
            }

            if (this.txtSource.Text.Trim() == string.Empty)
            {
                MessageBox.Show("必须输入原始文本进行翻译！", "文本翻译", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.btnBrowse.Focus();
                return;
            }

            // 记录文本翻译开始时间
            DateTime begin = DateTime.Now;

            // 根据用户选择使用 Google 或百度翻译 API 翻译文本
            this.txtDestination.Text =
                this.engine == "google" ?
                this.googleTrans_Get(this.txtLanguageOriginal.Text, this.txtLanguageDestination.Text, this.txtSource.Text) :
                this.baiduTrans_Post(this.txtLanguageOriginal.Text, this.txtLanguageDestination.Text, this.txtSource.Text);

            if (this.txtDestination.Text != string.Empty)
            {
                // 记录文本翻译结束时间
                DateTime end = DateTime.Now;

                MessageBox.Show("翻译完成！\r\n\r\n耗时： " + (end - begin).TotalSeconds.ToString() + " 秒。", "文本翻译", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }


        /// <summary>
        /// 单击单选按钮切换翻译引擎
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void radGoogle_CheckedChanged(object sender, EventArgs e)
        {
            this.engine = this.radGoogle.Checked ? "google" : "baidu";
        }


        /// <summary>
        /// 选择待翻译 Word 文档按钮
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnBrowse_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog ofd = new OpenFileDialog())
            {
                ofd.Filter = "Word 文档(*.docx, *.doc)|*.docx;*.doc";
                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    this.txtDocFilePath.Text = ofd.FileName;
                }
            }
        }


        /// <summary>
        /// 选择翻译后文档的保存路径按钮
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnBrowseNew_Click(object sender, EventArgs e)
        {
            using (FolderBrowserDialog fbd = new FolderBrowserDialog())
            {
                if (fbd.ShowDialog() == DialogResult.OK)
                {
                    this.txtNewDocPath.Text = fbd.SelectedPath;
                }
            }
        }



        #endregion



    }
}
