﻿namespace BatchTranslator
{
    partial class frmMain
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.txtSource = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtDocFilePath = new System.Windows.Forms.TextBox();
            this.btnTransDoc = new System.Windows.Forms.Button();
            this.radGoogle = new System.Windows.Forms.RadioButton();
            this.radBaidu = new System.Windows.Forms.RadioButton();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtDestination = new System.Windows.Forms.TextBox();
            this.btnBrowse = new System.Windows.Forms.Button();
            this.btnTranText = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txtLanguageOriginal = new System.Windows.Forms.TextBox();
            this.txtLanguageDestination = new System.Windows.Forms.TextBox();
            this.btnSwapLanguage = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.lllGoogle = new System.Windows.Forms.LinkLabel();
            this.lllBaidu = new System.Windows.Forms.LinkLabel();
            this.txtNewDocPath = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.btnBrowseNew = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtSource
            // 
            this.txtSource.Location = new System.Drawing.Point(83, 106);
            this.txtSource.Multiline = true;
            this.txtSource.Name = "txtSource";
            this.txtSource.Size = new System.Drawing.Size(380, 127);
            this.txtSource.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 12);
            this.label1.TabIndex = 3;
            this.label1.Text = "原始文档：";
            // 
            // txtDocFilePath
            // 
            this.txtDocFilePath.BackColor = System.Drawing.Color.White;
            this.txtDocFilePath.Location = new System.Drawing.Point(83, 16);
            this.txtDocFilePath.Name = "txtDocFilePath";
            this.txtDocFilePath.ReadOnly = true;
            this.txtDocFilePath.Size = new System.Drawing.Size(299, 21);
            this.txtDocFilePath.TabIndex = 4;
            // 
            // btnTransDoc
            // 
            this.btnTransDoc.Location = new System.Drawing.Point(469, 16);
            this.btnTransDoc.Name = "btnTransDoc";
            this.btnTransDoc.Size = new System.Drawing.Size(75, 55);
            this.btnTransDoc.TabIndex = 5;
            this.btnTransDoc.Text = "翻译(&D)";
            this.btnTransDoc.UseVisualStyleBackColor = true;
            this.btnTransDoc.Click += new System.EventHandler(this.btnTransDoc_Click);
            // 
            // radGoogle
            // 
            this.radGoogle.AutoSize = true;
            this.radGoogle.Checked = true;
            this.radGoogle.Location = new System.Drawing.Point(128, 414);
            this.radGoogle.Name = "radGoogle";
            this.radGoogle.Size = new System.Drawing.Size(245, 16);
            this.radGoogle.TabIndex = 6;
            this.radGoogle.TabStop = true;
            this.radGoogle.Text = "Google Cloud Platform Translation API";
            this.radGoogle.UseVisualStyleBackColor = true;
            this.radGoogle.CheckedChanged += new System.EventHandler(this.radGoogle_CheckedChanged);
            // 
            // radBaidu
            // 
            this.radBaidu.AutoSize = true;
            this.radBaidu.Location = new System.Drawing.Point(379, 414);
            this.radBaidu.Name = "radBaidu";
            this.radBaidu.Size = new System.Drawing.Size(119, 16);
            this.radBaidu.TabIndex = 7;
            this.radBaidu.Text = "百度翻译开放平台";
            this.radBaidu.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(56, 416);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 12);
            this.label2.TabIndex = 8;
            this.label2.Text = "翻译引擎：";
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(14, 388);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(533, 23);
            this.label3.TabIndex = 9;
            this.label3.Text = "————————————————————————————————————————————";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 107);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(65, 12);
            this.label4.TabIndex = 10;
            this.label4.Text = "原始文本：";
            // 
            // label5
            // 
            this.label5.Location = new System.Drawing.Point(11, 85);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(533, 23);
            this.label5.TabIndex = 11;
            this.label5.Text = "————————————————————————————————————————————";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 248);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(65, 12);
            this.label6.TabIndex = 13;
            this.label6.Text = "翻译结果：";
            // 
            // txtDestination
            // 
            this.txtDestination.Location = new System.Drawing.Point(83, 247);
            this.txtDestination.Multiline = true;
            this.txtDestination.Name = "txtDestination";
            this.txtDestination.Size = new System.Drawing.Size(380, 127);
            this.txtDestination.TabIndex = 12;
            // 
            // btnBrowse
            // 
            this.btnBrowse.Location = new System.Drawing.Point(388, 15);
            this.btnBrowse.Name = "btnBrowse";
            this.btnBrowse.Size = new System.Drawing.Size(75, 21);
            this.btnBrowse.TabIndex = 14;
            this.btnBrowse.Text = "浏览(&B)";
            this.btnBrowse.UseVisualStyleBackColor = true;
            this.btnBrowse.Click += new System.EventHandler(this.btnBrowse_Click);
            // 
            // btnTranText
            // 
            this.btnTranText.Location = new System.Drawing.Point(469, 213);
            this.btnTranText.Name = "btnTranText";
            this.btnTranText.Size = new System.Drawing.Size(75, 55);
            this.btnTranText.TabIndex = 15;
            this.btnTranText.Text = "翻译(&T)";
            this.btnTranText.UseVisualStyleBackColor = true;
            this.btnTranText.Click += new System.EventHandler(this.btnTranText_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(56, 448);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(65, 12);
            this.label7.TabIndex = 16;
            this.label7.Text = "原始语言：";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(331, 448);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(65, 12);
            this.label8.TabIndex = 19;
            this.label8.Text = "目标语言：";
            // 
            // txtLanguageOriginal
            // 
            this.txtLanguageOriginal.Location = new System.Drawing.Point(128, 444);
            this.txtLanguageOriginal.Name = "txtLanguageOriginal";
            this.txtLanguageOriginal.Size = new System.Drawing.Size(92, 21);
            this.txtLanguageOriginal.TabIndex = 20;
            this.txtLanguageOriginal.Text = "en";
            // 
            // txtLanguageDestination
            // 
            this.txtLanguageDestination.Location = new System.Drawing.Point(402, 444);
            this.txtLanguageDestination.Name = "txtLanguageDestination";
            this.txtLanguageDestination.Size = new System.Drawing.Size(92, 21);
            this.txtLanguageDestination.TabIndex = 21;
            this.txtLanguageDestination.Text = "zh";
            // 
            // btnSwapLanguage
            // 
            this.btnSwapLanguage.Location = new System.Drawing.Point(253, 444);
            this.btnSwapLanguage.Name = "btnSwapLanguage";
            this.btnSwapLanguage.Size = new System.Drawing.Size(51, 21);
            this.btnSwapLanguage.TabIndex = 22;
            this.btnSwapLanguage.Text = "«  »";
            this.btnSwapLanguage.UseVisualStyleBackColor = true;
            this.btnSwapLanguage.Click += new System.EventHandler(this.btnSwapLanguage_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(56, 479);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(185, 12);
            this.label9.TabIndex = 23;
            this.label9.Text = "不同引擎支持的语言列表分别在：";
            // 
            // lllGoogle
            // 
            this.lllGoogle.Location = new System.Drawing.Point(56, 500);
            this.lllGoogle.Name = "lllGoogle";
            this.lllGoogle.Size = new System.Drawing.Size(438, 20);
            this.lllGoogle.TabIndex = 24;
            this.lllGoogle.TabStop = true;
            this.lllGoogle.Text = "https://cloud.google.com/translate/docs/languages";
            this.lllGoogle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lllGoogle.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lllGoogle_LinkClicked);
            // 
            // lllBaidu
            // 
            this.lllBaidu.Location = new System.Drawing.Point(56, 521);
            this.lllBaidu.Name = "lllBaidu";
            this.lllBaidu.Size = new System.Drawing.Size(438, 20);
            this.lllBaidu.TabIndex = 25;
            this.lllBaidu.TabStop = true;
            this.lllBaidu.Text = "http://api.fanyi.baidu.com/api/trans/product/apidoc#languageList";
            this.lllBaidu.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lllBaidu.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lllBaidu_LinkClicked);
            // 
            // txtNewDocPath
            // 
            this.txtNewDocPath.BackColor = System.Drawing.Color.White;
            this.txtNewDocPath.Location = new System.Drawing.Point(83, 50);
            this.txtNewDocPath.Name = "txtNewDocPath";
            this.txtNewDocPath.ReadOnly = true;
            this.txtNewDocPath.Size = new System.Drawing.Size(299, 21);
            this.txtNewDocPath.TabIndex = 27;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(12, 54);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(65, 12);
            this.label10.TabIndex = 26;
            this.label10.Text = "翻译文档：";
            // 
            // btnBrowseNew
            // 
            this.btnBrowseNew.Location = new System.Drawing.Point(388, 50);
            this.btnBrowseNew.Name = "btnBrowseNew";
            this.btnBrowseNew.Size = new System.Drawing.Size(75, 21);
            this.btnBrowseNew.TabIndex = 28;
            this.btnBrowseNew.Text = "浏览(&B)";
            this.btnBrowseNew.UseVisualStyleBackColor = true;
            this.btnBrowseNew.Click += new System.EventHandler(this.btnBrowseNew_Click);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(559, 558);
            this.Controls.Add(this.btnBrowseNew);
            this.Controls.Add(this.txtNewDocPath);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.lllBaidu);
            this.Controls.Add(this.lllGoogle);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.btnSwapLanguage);
            this.Controls.Add(this.txtLanguageDestination);
            this.Controls.Add(this.txtLanguageOriginal);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.btnTranText);
            this.Controls.Add(this.btnBrowse);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtDestination);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.radBaidu);
            this.Controls.Add(this.radGoogle);
            this.Controls.Add(this.btnTransDoc);
            this.Controls.Add(this.txtDocFilePath);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtSource);
            this.Controls.Add(this.label5);
            this.MaximizeBox = false;
            this.Name = "frmMain";
            this.Text = "文档/文本云翻译";
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtSource;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtDocFilePath;
        private System.Windows.Forms.Button btnTransDoc;
        private System.Windows.Forms.RadioButton radGoogle;
        private System.Windows.Forms.RadioButton radBaidu;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtDestination;
        private System.Windows.Forms.Button btnBrowse;
        private System.Windows.Forms.Button btnTranText;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtLanguageOriginal;
        private System.Windows.Forms.TextBox txtLanguageDestination;
        private System.Windows.Forms.Button btnSwapLanguage;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.LinkLabel lllGoogle;
        private System.Windows.Forms.LinkLabel lllBaidu;
        private System.Windows.Forms.TextBox txtNewDocPath;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button btnBrowseNew;
    }
}

